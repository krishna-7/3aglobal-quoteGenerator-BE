<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            UserTypeSeeder::class,
            UserSeeder::class,
            MenuSeeder::class,
            PaymentProviderSeeder::class,
            PaymentModeSeeder::class,
            TransactionTypeSeeder::class
        ]);
    }
}
